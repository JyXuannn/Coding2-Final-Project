from app import db

from . import home
from flask import render_template, redirect, url_for, flash, session, request, jsonify, send_file, current_app
from app.models import *
from sqlalchemy import or_, and_
from functools import wraps
from decimal import *
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
import os
import time
from datetime import datetime, date
import random
import numpy as np
import copy
import json

@home.route('/')
def index():
    return render_template('home/index.html')

@home.route('/pc/0', methods=["GET","POST"])
# @home_login
def pc_0():
    if request.method == "GET":
        return render_template('home/pc_0.html')

@home.route('/pc/832')
def pc_832():
    return jsonify('You can try 8**32')


@home.route('/pc/people')
def people():
    if request.method == "GET":
        return render_template('home/people.html')

@home.route('/pc/79228162514264337593543950336')
def math():
    return redirect(url_for('home.riddle'))

@home.route('/pc/riddle')
def riddle():
    return render_template('home/4.html')

@home.route('/pc/215656')
def final():
    return render_template('home/215656.html')


@home.route('/download')
def download():
    filename = 'test\\test.py'
    path = os.path.join(current_app.root_path, 'static', filename)
    return send_file(path, as_attachment=True)

@home.route('/download_file')
def download_file():
    filename = 'test\\img_align_celeba.7z'
    path = os.path.join(current_app.root_path, 'static', filename)
    return send_file(path, as_attachment=True)