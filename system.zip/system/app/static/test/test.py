"""
    Q1
"""
print(8**32)
"""
    Q2
"""
# people
"""
    Q3
"""
import numpy as np
import matplotlib.pyplot as plt
plt.style.use('ggplot')
import os
files = os.listdir('img_align_celeba')

print(os.path.join('img_align_celeba', files[0]))
plt.imread(os.path.join('img_align_celeba', files[0]))

files = [os.path.join('img_align_celeba', file_i)
 for file_i in os.listdir('img_align_celeba')
 if '.jpg' in file_i]
imgs = [plt.imread(files[file_i])
        for file_i in range(99)]

data = np.array(imgs)
flattened = data.ravel()
max_value = plt.hist(flattened.ravel(), 255)[0].max()
print('max', max_value)
plt.show()
