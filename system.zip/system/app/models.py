from . import db
from datetime import datetime
from sqlalchemy.orm import relationship

# 会员数据模型
class User(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)  # 编号
    username = db.Column(db.String(100)) # 用户名
    password = db.Column(db.String(150))  # 密码
    addtime = db.Column(db.DateTime, index=True, default=datetime.now)  # 注册时间
    status = db.Column(db.Integer, default=0)
    rank_count = db.Column(db.Integer, default=0)
    age = db.Column(db.Integer, default=0)
    sex = db.Column(db.String(5), default='女')
    favorite = db.Column(db.String(50), default=0)
    email = db.Column(db.String(50), default='default@example.com')
    avatar = db.Column(db.String(50), default='home/assets/images/dashboard/profile.png')

    def __repr__(self):
        return '<User %r>' % self.username

    def check_password(self, password):
        """
        检测密码是否正确
        :param password: 密码
        :return: 返回布尔值
        """
        from werkzeug.security import check_password_hash
        return check_password_hash(self.password, password)
